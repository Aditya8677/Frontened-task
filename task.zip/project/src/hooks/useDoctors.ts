import { useEffect, useMemo, useState } from 'react';
import { fetchDoctors } from '../api/doctorsApi';
import { ConsultationType, Doctor, FilterState, SortOption } from '../types/types';

export const useDoctors = (filters: FilterState) => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch doctors on mount
  useEffect(() => {
    const getDoctors = async () => {
      try {
        setLoading(true);
        const data = await fetchDoctors();
        setDoctors(data);
        setError(null);
      } catch (err) {
        setError('Failed to fetch doctors. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    getDoctors();
  }, []);

  // Filter and sort doctors based on filters
  const filteredDoctors = useMemo(() => {
    let result = [...doctors];

    // Filter by search term
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      result = result.filter(
        doctor => doctor.name.toLowerCase().includes(searchTerm)
      );
    }

    // Filter by consultation type
    if (filters.consultationType !== 'All') {
      result = result.filter(doctor => 
        doctor.consultationType === filters.consultationType || 
        doctor.consultationType === 'Both'
      );
    }

    // Filter by specialties
    if (filters.specialties.length > 0) {
      result = result.filter(doctor =>
        filters.specialties.includes(doctor.specialty)
      );
    }

    // Sort doctors
    if (filters.sortBy === 'fees-asc') {
      result.sort((a, b) => a.fee - b.fee);
    } else if (filters.sortBy === 'experience-desc') {
      result.sort((a, b) => b.experience - a.experience);
    }

    return result;
  }, [doctors, filters]);

  // Get unique specialties for filter options
  const specialties = useMemo(() => {
    const specialtySet = new Set(doctors.map(doctor => doctor.specialty));
    return Array.from(specialtySet);
  }, [doctors]);

  return {
    doctors: filteredDoctors,
    specialties,
    loading,
    error
  };
};