import { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ConsultationType, FilterState, SortOption } from '../types/types';

const DEFAULT_FILTERS: FilterState = {
  search: '',
  consultationType: 'All',
  specialties: [],
  sortBy: 'fees-asc',
};

export const useURLParams = (): [FilterState, (newFilters: Partial<FilterState>) => void] => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);

  // Load filters from URL params on mount
  useEffect(() => {
    const search = searchParams.get('search') || DEFAULT_FILTERS.search;
    const consultationType = (searchParams.get('consultationType') as ConsultationType) || DEFAULT_FILTERS.consultationType;
    const specialties = searchParams.get('specialties') ? searchParams.get('specialties')!.split(',') : DEFAULT_FILTERS.specialties;
    const sortBy = (searchParams.get('sortBy') as SortOption) || DEFAULT_FILTERS.sortBy;

    setFilters({
      search,
      consultationType,
      specialties,
      sortBy,
    });
  }, [searchParams]);

  // Update URL params when filters change
  const updateFilters = useCallback((newFilters: Partial<FilterState>) => {
    const updatedFilters = { ...filters, ...newFilters };
    
    // Update search params
    const params = new URLSearchParams();
    
    if (updatedFilters.search) {
      params.set('search', updatedFilters.search);
    }
    
    if (updatedFilters.consultationType !== 'All') {
      params.set('consultationType', updatedFilters.consultationType);
    }
    
    if (updatedFilters.specialties.length > 0) {
      params.set('specialties', updatedFilters.specialties.join(','));
    }
    
    if (updatedFilters.sortBy) {
      params.set('sortBy', updatedFilters.sortBy);
    }
    
    setSearchParams(params);
  }, [filters, setSearchParams]);

  return [filters, updateFilters];
};