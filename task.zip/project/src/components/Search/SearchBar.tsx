import React, { useState, useRef, useEffect } from 'react';
import { Doctor } from '../../types/types';
import { getDoctorSuggestions } from '../../api/doctorsApi';
import SearchSuggestion from './SearchSuggestion';
import { Search } from 'lucide-react';

interface SearchBarProps {
  doctors: Doctor[];
  value: string;
  onChange: (value: string) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ doctors, value, onChange }) => {
  const [focused, setFocused] = useState(false);
  const [suggestions, setSuggestions] = useState<Doctor[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLUListElement>(null);

  // Update suggestions when search term changes
  useEffect(() => {
    if (value) {
      setSuggestions(getDoctorSuggestions(doctors, value));
    } else {
      setSuggestions([]);
    }
  }, [value, doctors]);

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        suggestionsRef.current && 
        !suggestionsRef.current.contains(event.target as Node) &&
        !inputRef.current?.contains(event.target as Node)
      ) {
        setFocused(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange(e.target.value);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && value) {
      setFocused(false);
    }
  };

  const handleSuggestionClick = (doctor: Doctor) => {
    onChange(doctor.name);
    setFocused(false);
  };

  return (
    <div className="relative w-full max-w-md">
      <div className="relative">
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          ref={inputRef}
          type="text"
          data-testid="autocomplete-input"
          className="w-full py-3 pl-10 pr-4 text-gray-700 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Search for a doctor..."
          value={value}
          onChange={handleInputChange}
          onFocus={() => setFocused(true)}
          onKeyDown={handleKeyDown}
        />
      </div>

      {focused && suggestions.length > 0 && (
        <ul
          ref={suggestionsRef}
          className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden transition-all duration-200 ease-in-out"
        >
          {suggestions.map((doctor) => (
            <SearchSuggestion
              key={doctor.id}
              doctor={doctor}
              onClick={handleSuggestionClick}
            />
          ))}
        </ul>
      )}
    </div>
  );
};

export default SearchBar;