import React from 'react';
import { Doctor } from '../../types/types';

interface SearchSuggestionProps {
  doctor: Doctor;
  onClick: (doctor: Doctor) => void;
}

const SearchSuggestion: React.FC<SearchSuggestionProps> = ({ doctor, onClick }) => {
  return (
    <li 
      data-testid="suggestion-item"
      className="py-2 px-4 hover:bg-blue-50 transition-colors cursor-pointer"
      onClick={() => onClick(doctor)}
    >
      <div className="flex items-center gap-2">
        <span className="font-medium">{doctor.name}</span>
        <span className="text-sm text-gray-500">({doctor.specialty})</span>
      </div>
    </li>
  );
};

export default SearchSuggestion;