import React from 'react';
import { ConsultationType } from '../../types/types';
import { Video, UserRound } from 'lucide-react';

interface ConsultationTypeFilterProps {
  value: ConsultationType;
  onChange: (value: ConsultationType) => void;
}

const ConsultationTypeFilter: React.FC<ConsultationTypeFilterProps> = ({ value, onChange }) => {
  const options: { label: string; value: ConsultationType; icon: React.ReactNode }[] = [
    { 
      label: 'All', 
      value: 'All', 
      icon: null 
    },
    { 
      label: 'Video Consult', 
      value: 'Video Consult', 
      icon: <Video className="h-4 w-4 text-blue-500" /> 
    },
    { 
      label: 'In Clinic', 
      value: 'In Clinic', 
      icon: <UserRound className="h-4 w-4 text-teal-600" /> 
    },
  ];

  return (
    <div className="mb-6">
      <h3 className="text-sm font-medium text-gray-700 mb-2">Consultation Type</h3>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => (
          <label 
            key={option.value}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-full border cursor-pointer transition-all
              ${value === option.value 
                ? 'bg-blue-50 border-blue-500 text-blue-700' 
                : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}
            `}
          >
            <input
              type="radio"
              name="consultationType"
              value={option.value}
              checked={value === option.value}
              onChange={() => onChange(option.value)}
              className="sr-only"
            />
            {option.icon}
            <span>{option.label}</span>
          </label>
        ))}
      </div>
    </div>
  );
};

export default ConsultationTypeFilter;