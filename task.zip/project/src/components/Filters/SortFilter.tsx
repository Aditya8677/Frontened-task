import React from 'react';
import { SortOption } from '../../types/types';
import { ArrowDownNarrowWide, ArrowUpNarrowWide } from 'lucide-react';

interface SortFilterProps {
  value: SortOption;
  onChange: (value: SortOption) => void;
}

const SortFilter: React.FC<SortFilterProps> = ({ value, onChange }) => {
  const options: { label: string; value: SortOption; icon: React.ReactNode }[] = [
    { 
      label: 'Fees: Low to High', 
      value: 'fees-asc',
      icon: <ArrowUpNarrowWide className="h-4 w-4" />
    },
    { 
      label: 'Experience: High to Low', 
      value: 'experience-desc',
      icon: <ArrowDownNarrowWide className="h-4 w-4" /> 
    },
  ];

  return (
    <div className="mb-6">
      <h3 className="text-sm font-medium text-gray-700 mb-2">Sort By</h3>
      <div className="flex flex-col space-y-2">
        {options.map((option) => (
          <label
            key={option.value}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-md border cursor-pointer transition-all
              ${value === option.value
                ? 'bg-blue-50 border-blue-500 text-blue-700'
                : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}
            `}
          >
            <input
              type="radio"
              name="sortBy"
              value={option.value}
              checked={value === option.value}
              onChange={() => onChange(option.value)}
              className="sr-only"
            />
            {option.icon}
            <span>{option.label}</span>
          </label>
        ))}
      </div>
    </div>
  );
};

export default SortFilter;