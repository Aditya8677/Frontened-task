import React from 'react';
import { ConsultationType, FilterState, SortOption } from '../../types/types';
import ConsultationTypeFilter from './ConsultationTypeFilter';
import SpecialtyFilter from './SpecialtyFilter';
import SortFilter from './SortFilter';
import { SlidersHorizontal } from 'lucide-react';

interface FilterPanelProps {
  filters: FilterState;
  updateFilters: (newFilters: Partial<FilterState>) => void;
  specialties: string[];
  filterCount: number;
}

const FilterPanel: React.FC<FilterPanelProps> = ({ 
  filters, 
  updateFilters, 
  specialties,
  filterCount 
}) => {
  const [isOpen, setIsOpen] = React.useState(false);

  const handleConsultationTypeChange = (consultationType: ConsultationType) => {
    updateFilters({ consultationType });
  };

  const handleSpecialtiesChange = (specialties: string[]) => {
    updateFilters({ specialties });
  };

  const handleSortChange = (sortBy: SortOption) => {
    updateFilters({ sortBy });
  };

  return (
    <>
      {/* Mobile filter button */}
      <div className="md:hidden mb-4">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center justify-center gap-2 w-full py-2 px-4 bg-white border border-gray-300 rounded-lg shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <SlidersHorizontal className="h-4 w-4" />
          <span>Filters</span>
          {filterCount > 0 && (
            <span className="ml-1 px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full text-xs">
              {filterCount}
            </span>
          )}
        </button>
      </div>

      {/* Filter panel */}
      <div 
        className={`
          bg-white p-4 rounded-lg shadow-md border border-gray-200
          md:block
          ${isOpen ? 'block' : 'hidden'}
        `}
      >
        <div className="flex items-center justify-between mb-4 md:hidden">
          <h2 className="text-lg font-medium text-gray-900">Filters</h2>
          <button
            onClick={() => setIsOpen(false)}
            className="text-gray-500 hover:text-gray-700"
          >
            ✕
          </button>
        </div>

        <ConsultationTypeFilter 
          value={filters.consultationType} 
          onChange={handleConsultationTypeChange}
        />
        
        <SpecialtyFilter 
          specialties={specialties} 
          selectedSpecialties={filters.specialties} 
          onChange={handleSpecialtiesChange}
        />
        
        <SortFilter 
          value={filters.sortBy} 
          onChange={handleSortChange}
        />

        {/* Reset filters button (mobile only) */}
        <div className="md:hidden mt-4">
          <button
            onClick={() => {
              updateFilters({
                consultationType: 'All',
                specialties: [],
                sortBy: 'fees-asc'
              });
              setIsOpen(false);
            }}
            className="w-full py-2 px-4 bg-gray-100 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            Reset Filters
          </button>
        </div>
      </div>
    </>
  );
};

export default FilterPanel;