import React from 'react';
import { Check } from 'lucide-react';

interface SpecialtyFilterProps {
  specialties: string[];
  selectedSpecialties: string[];
  onChange: (specialties: string[]) => void;
}

const SpecialtyFilter: React.FC<SpecialtyFilterProps> = ({ 
  specialties, 
  selectedSpecialties, 
  onChange 
}) => {
  const handleSpecialtyChange = (specialty: string) => {
    const isSelected = selectedSpecialties.includes(specialty);
    
    if (isSelected) {
      onChange(selectedSpecialties.filter((s) => s !== specialty));
    } else {
      onChange([...selectedSpecialties, specialty]);
    }
  };

  return (
    <div className="mb-6">
      <h3 className="text-sm font-medium text-gray-700 mb-2">Specialties</h3>
      <div className="max-h-48 overflow-y-auto pr-2 space-y-2">
        {specialties.map((specialty) => (
          <label 
            key={specialty} 
            className="flex items-center space-x-3 cursor-pointer"
          >
            <div 
              className={`
                w-5 h-5 border rounded flex items-center justify-center transition-colors
                ${selectedSpecialties.includes(specialty) 
                  ? 'bg-blue-500 border-blue-500' 
                  : 'border-gray-300'}
              `}
            >
              {selectedSpecialties.includes(specialty) && (
                <Check className="h-3 w-3 text-white" />
              )}
            </div>
            <input
              type="checkbox"
              className="sr-only"
              checked={selectedSpecialties.includes(specialty)}
              onChange={() => handleSpecialtyChange(specialty)}
            />
            <span className="text-sm text-gray-700">{specialty}</span>
          </label>
        ))}
      </div>
    </div>
  );
};

export default SpecialtyFilter;