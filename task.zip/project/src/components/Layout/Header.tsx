import React from 'react';
import SearchBar from '../Search/SearchBar';
import { Doctor } from '../../types/types';
import { stethoscope } from 'lucide-react';

interface HeaderProps {
  doctors: Doctor[];
  searchTerm: string;
  onSearchChange: (value: string) => void;
}

const Header: React.FC<HeaderProps> = ({ doctors, searchTerm, onSearchChange }) => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="h-8 w-8 mr-2 text-white"
            >
              <path d="M4.8 2.3A.3.3 0 1 0 5 2H4a2 2 0 0 0-2 2v5a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6V4a2 2 0 0 0-2-2h-1a.2.2 0 1 0 .3.3" />
              <path d="M8 15v1a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6v-4" />
              <circle cx="20" cy="10" r="2" />
            </svg>
            <h1 className="text-2xl font-bold">DocFinder</h1>
          </div>
          
          <div className="w-full md:max-w-md">
            <SearchBar 
              doctors={doctors} 
              value={searchTerm} 
              onChange={onSearchChange} 
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;