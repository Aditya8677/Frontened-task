import React from 'react';
import { Doctor } from '../../types/types';
import { Award, DollarSign, Video, UserRound } from 'lucide-react';

interface DoctorCardProps {
  doctor: Doctor;
}

const DoctorCard: React.FC<DoctorCardProps> = ({ doctor }) => {
  return (
    <div 
      data-testid="doctor-card"
      className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-200 transition-transform duration-300 hover:shadow-lg hover:-translate-y-1"
    >
      <div className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 
              data-testid="doctor-name" 
              className="text-lg font-bold text-gray-900 mb-1"
            >
              Dr. {doctor.name}
            </h3>
            <p 
              data-testid="doctor-specialty"
              className="text-sm font-medium text-blue-600 mb-3"
            >
              {doctor.specialty}
            </p>
            
            <div className="flex flex-wrap gap-4 mt-4">
              <div className="flex items-center gap-1.5">
                <Award className="h-4 w-4 text-amber-500" />
                <span 
                  data-testid="doctor-experience"
                  className="text-sm text-gray-700"
                >
                  {doctor.experience} years
                </span>
              </div>
              
              <div className="flex items-center gap-1.5">
                <DollarSign className="h-4 w-4 text-green-600" />
                <span 
                  data-testid="doctor-fee"
                  className="text-sm text-gray-700"
                >
                  ${doctor.fee}
                </span>
              </div>
            </div>
          </div>
          
          {doctor.profilePic ? (
            <img 
              src={doctor.profilePic} 
              alt={doctor.name} 
              className="w-16 h-16 rounded-full object-cover border-2 border-gray-200"
            />
          ) : (
            <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
              <span className="text-blue-800 text-xl font-bold">
                {doctor.name.charAt(0)}
              </span>
            </div>
          )}
        </div>
        
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="flex gap-2">
            {(doctor.consultationType === 'Video Consult' || doctor.consultationType === 'Both') && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                <Video className="h-3 w-3 mr-1" />
                Video Consult
              </span>
            )}
            
            {(doctor.consultationType === 'In Clinic' || doctor.consultationType === 'Both') && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-teal-100 text-teal-800">
                <UserRound className="h-3 w-3 mr-1" />
                In Clinic
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DoctorCard;