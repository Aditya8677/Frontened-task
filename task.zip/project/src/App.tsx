import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import DoctorFinderPage from './pages/DoctorFinderPage';

function App() {
  return (
    <BrowserRouter>
      <DoctorFinderPage />
    </BrowserRouter>
  );
}

export default App;