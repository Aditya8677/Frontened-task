import { Doctor } from '../types/types';

const API_URL = 'https://srijandubey.github.io/campus-api-mock/SRM-C1-25.json';

export const fetchDoctors = async (): Promise<Doctor[]> => {
  try {
    const response = await fetch(API_URL);
    
    if (!response.ok) {
      throw new Error(`Error fetching doctors: ${response.status}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Failed to fetch doctors:', error);
    return [];
  }
};

export const getDoctorSuggestions = (doctors: Doctor[], searchTerm: string): Doctor[] => {
  if (!searchTerm.trim()) return [];
  
  const normalizedSearchTerm = searchTerm.toLowerCase().trim();
  
  return doctors
    .filter(doctor => 
      doctor.name.toLowerCase().includes(normalizedSearchTerm)
    )
    .slice(0, 3);
};