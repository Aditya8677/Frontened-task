export interface Doctor {
  id: number;
  name: string;
  specialty: string;
  experience: number;
  fee: number;
  consultationType: 'Video Consult' | 'In Clinic' | 'Both';
  profilePic?: string;
  rating?: number;
  location?: string;
}

export type ConsultationType = 'Video Consult' | 'In Clinic' | 'All';

export type SortOption = 'fees-asc' | 'experience-desc';

export interface FilterState {
  search: string;
  consultationType: ConsultationType;
  specialties: string[];
  sortBy: SortOption;
}