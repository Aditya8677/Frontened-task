import React, { useMemo } from 'react';
import Header from '../components/Layout/Header';
import FilterPanel from '../components/Filters/FilterPanel';
import DoctorList from '../components/DoctorList/DoctorList';
import { useDoctors } from '../hooks/useDoctors';
import { useURLParams } from '../hooks/useURLParams';

const DoctorFinderPage: React.FC = () => {
  const [filters, updateFilters] = useURLParams();
  const { doctors, specialties, loading, error } = useDoctors(filters);

  const filterCount = useMemo(() => {
    let count = 0;
    
    if (filters.consultationType !== 'All') count++;
    if (filters.specialties.length > 0) count++;
    if (filters.sortBy !== 'fees-asc') count++;
    
    return count;
  }, [filters]);

  const handleSearchChange = (value: string) => {
    updateFilters({ search: value });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header 
        doctors={loading ? [] : doctors}
        searchTerm={filters.search} 
        onSearchChange={handleSearchChange} 
      />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Sidebar - Filters */}
          <div className="md:col-span-1">
            <FilterPanel 
              filters={filters} 
              updateFilters={updateFilters} 
              specialties={specialties}
              filterCount={filterCount}
            />
          </div>
          
          {/* Main Content - Doctor List */}
          <div className="md:col-span-3">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {loading ? 'Loading doctors...' : `${doctors.length} Doctors Found`}
              </h2>
              {filters.search && (
                <p className="text-gray-600 mt-1">
                  Search results for: <span className="font-medium">{filters.search}</span>
                </p>
              )}
            </div>
            
            <DoctorList 
              doctors={doctors} 
              loading={loading} 
              error={error} 
            />
          </div>
        </div>
      </main>
      
      <footer className="mt-auto bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; {new Date().getFullYear()} DocFinder. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default DoctorFinderPage;